from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from app.graphs.jd_matching.graph import jd_matching_graph
from app.db.repositories.match_repository import (
    create_job_description_record,
    create_match_result_records,
)


router = APIRouter(
    prefix="/api/jd-matching",
    tags=["JD Matching"],
)


class JDMatchRequest(BaseModel):
    jd_text: str


@router.post("/match")
def match_jd(request: JDMatchRequest):
    jd_text = request.jd_text.strip()

    if not jd_text:
        raise HTTPException(
            status_code=400,
            detail="JD text is required.",
        )

    try:
        result = jd_matching_graph.invoke(
            {
                "jd_text": jd_text,
                "jd_id": None,

                "jd_skills": [],
                "experience_min": None,
                "experience_max": None,
                "jd_role": None,
                "jd_location": None,

                "candidates": [],

                "matches": [],
                "ranked_matches": [],

                "business_decision": None,

                "errors": [],
                "status": "STARTED",
            }
        )

        jd_id = create_job_description_record(
            raw_text=jd_text,
            role=result.get("jd_role"),
            location=result.get("jd_location"),
            experience_min=result.get("experience_min"),
            experience_max=result.get("experience_max"),
        )

        matches = result.get("ranked_matches", [])
        saved_match_results = create_match_result_records(
            jd_id=jd_id,
            matches=matches,
        )

        return {
            "status": result.get("status"),
            "jd_id": jd_id,
            "jd": {
                "skills": result.get("jd_skills", []),
                "role": result.get("jd_role"),
                "location": result.get("jd_location"),
                "experience_min": result.get("experience_min"),
                "experience_max": result.get("experience_max"),
            },
            "matches": matches,
            "saved_match_results": saved_match_results,
            "business_decision": result.get("business_decision"),
            "errors": result.get("errors", []),
        }

    except Exception as exc:
        raise HTTPException(
            status_code=500,
            detail=f"JD matching failed: {str(exc)}",
        )