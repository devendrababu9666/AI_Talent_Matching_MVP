from typing import Any, Optional, TypedDict


class JDMatchingState(TypedDict):
    # Input
    jd_text: str
    jd_id: Optional[str]

    # Extracted JD information
    jd_skills: list[dict[str, Any]]
    jd_role: Optional[str]
    jd_location: Optional[str]
    experience_min: Optional[int]
    experience_max: Optional[int]

    # Candidate data from SQLite
    candidates: list[dict[str, Any]]

    # Matching output
    matches: list[dict[str, Any]]
    ranked_matches: list[dict[str, Any]]

    # Final business output
    business_decision: Optional[dict[str, Any]]

    # Workflow control/debugging
    errors: list[str]
    status: str