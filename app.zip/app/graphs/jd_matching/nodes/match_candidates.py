from app.services.llm_service import model
from app.graphs.jd_matching.nodes.prompts import compare_skills


def match_candidates(state):
    jd_skills = state.get("jd_skills") or []
    candidates = state.get("candidates") or []
    errors = state.get("errors") or []

    matches = []

    if not jd_skills:
        return {
            "matches": [],
            "errors": ["No JD skills available for matching."],
            "status": "FAILED",
        }

    if not candidates:
        return {
            "matches": [],
            "errors": ["No candidates available for matching."],
            "status": "FAILED",
        }

    for candidate in candidates:
        try:
            candidate_skills = candidate.get("skills") or []

            prompt = compare_skills(
                candidate_skills=candidate_skills,
                jd_skills=jd_skills,
            )

            result = model.generate_json(prompt)

            match_score = extract_match_score(result)

            matches.append(
                {
                    "candidate_id": candidate.get("id"),
                    "sap_id": candidate.get("sap_id"),
                    "name": candidate.get("name"),
                    "role": candidate.get("role"),
                    "experience_years": candidate.get("experience_years"),
                    "location": candidate.get("location"),
                    "status": candidate.get("status"),
                    "skills": candidate_skills,
                    "match_score": match_score,
                    "matching_summary": result.get("matching_summary", {}),
                    "matched_skills": result.get("matched_skills", []),
                    "unmatched_jd_skills": result.get("unmatched_jd_skills", []),
                    "additional_candidate_skills": result.get(
                        "additional_candidate_skills",
                        [],
                    ),
                    "assessment_insights": result.get("assessment_insights", {}),
                    "recommendation": result.get("assessment_insights", {}).get(
                        "recommendation",
                        "",
                    ),
                }
            )

        except Exception as exc:
            errors.append(
                f"Candidate matching failed for {candidate.get('sap_id')}: {str(exc)}"
            )

    return {
        "matches": matches,
        "errors": errors,
        "status": "MATCHING_COMPLETED",
    }


def extract_match_score(result: dict) -> int:
    assessment = result.get("assessment_insights") or {}
    matching_summary = result.get("matching_summary") or {}

    score = assessment.get("overall_fit_score")

    if score is None:
        score = matching_summary.get("match_percentage", 0)

    if score is None:
        score = 0

    if isinstance(score, str):
        score = score.replace("%", "").strip()

        try:
            score = float(score)
        except ValueError:
            score = 0

    if isinstance(score, float):
        score = round(score)

    if not isinstance(score, int):
        score = 0

    return max(0, min(score, 100))