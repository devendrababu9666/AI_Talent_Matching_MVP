from app.services.llm_service import model
from app.graphs.jd_matching.nodes.prompts import JD_EXTRACTION_PROMPT


def extract_jd(state):
    jd_text = state.get("jd_text", "")

    if not jd_text.strip():
        return {
            "jd_skills": [],
            "experience_min": None,
            "experience_max": None,
            "jd_role": None,
            "jd_location": None,
            "errors": ["JD text is empty."],
            "status": "FAILED",
        }

    try:
        prompt = JD_EXTRACTION_PROMPT.replace("{jd_text}", jd_text)

        extracted = model.generate_json(prompt)

        return {
            "jd_skills": extracted.get("skills", []),
            "experience_min": extracted.get("experience_min"),
            "experience_max": extracted.get("experience_max"),
            "jd_role": extracted.get("role"),
            "jd_location": extracted.get("location"),
            "errors": state.get("errors", []),
            "status": "JD_EXTRACTED",
        }

    except Exception as exc:
        return {
            "jd_skills": [],
            "experience_min": None,
            "experience_max": None,
            "jd_role": None,
            "jd_location": None,
            "errors": [f"JD extraction failed: {str(exc)}"],
            "status": "FAILED",
        }