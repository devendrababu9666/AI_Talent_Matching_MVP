def rank_candidates(state):
    matches = state.get("matches", [])
    errors = state.get("errors", [])

    ranked_matches = sorted(
        matches,
        key=lambda item: item.get("match_score", 0),
        reverse=True,
    )

    for index, match in enumerate(ranked_matches, start=1):
        match["rank"] = index

    return {
        "ranked_matches": ranked_matches,
        "matches": ranked_matches,
        "errors": errors,
        "status": "MATCHES_RANKED",
    }