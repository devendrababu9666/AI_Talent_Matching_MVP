def business_decision(state):
    matches = state.get("ranked_matches", []) or state.get("matches", [])
    errors = state.get("errors", [])

    if errors:
        return {
            "business_decision": {
                "supported": False,
                "recommendation": "JD matching completed with errors. Review the error details before using the results.",
                "errors": errors,
            },
            "status": "FAILED",
        }

    if not matches:
        return {
            "business_decision": {
                "supported": False,
                "recommendation": "No matching candidates were found for this JD.",
            },
            "status": "COMPLETED",
        }

    high_matches = [
        match
        for match in matches
        if match.get("match_score", 0) >= 80
    ]

    medium_matches = [
        match
        for match in matches
        if 60 <= match.get("match_score", 0) < 80
    ]

    available_matches = [
        match
        for match in matches
        if match.get("status") == "Available"
    ]

    top_match = matches[0]

    if high_matches:
        recommendation = (
            "Strong candidate matches found. Prioritize the highest-ranked available candidates "
            "for project discussion."
        )
    elif medium_matches:
        recommendation = (
            "Moderate candidate matches found. Review skill gaps before shortlisting."
        )
    else:
        recommendation = (
            "Only low-confidence matches found. Consider broadening the search criteria or reviewing candidates manually."
        )

    return {
        "business_decision": {
            "supported": len(matches) > 0,
            "total_matches": len(matches),
            "high_match_count": len(high_matches),
            "medium_match_count": len(medium_matches),
            "available_match_count": len(available_matches),
            "top_candidate": {
                "sap_id": top_match.get("sap_id"),
                "name": top_match.get("name"),
                "match_score": top_match.get("match_score"),
                "status": top_match.get("status"),
            },
            "recommendation": recommendation,
        },
        "status": "COMPLETED",
    }