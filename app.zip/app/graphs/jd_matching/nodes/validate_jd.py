def validate_jd(state):
    errors = state.get("errors") or []

    jd_skills = state.get("jd_skills") or []
    experience_min = state.get("experience_min")
    experience_max = state.get("experience_max")

    if not jd_skills:
        errors.append("No skills could be extracted from the JD.")

    if experience_min is not None:
        if not isinstance(experience_min, int):
            errors.append("Minimum experience must be an integer.")
        elif experience_min < 0:
            errors.append("Invalid minimum experience.")

    if experience_max is not None:
        if not isinstance(experience_max, int):
            errors.append("Maximum experience must be an integer.")
        elif experience_max < 0:
            errors.append("Invalid maximum experience.")

    if (
        isinstance(experience_min, int)
        and isinstance(experience_max, int)
        and experience_min > experience_max
    ):
        errors.append("Minimum experience cannot be greater than maximum experience.")

    if errors:
        return {
            "errors": errors,
            "status": "VALIDATION_FAILED",
        }

    return {
        "errors": [],
        "status": "JD_VALIDATED",
    }