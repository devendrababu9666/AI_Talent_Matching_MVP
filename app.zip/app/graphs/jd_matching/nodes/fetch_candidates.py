from app.db.repositories.candidate_repository import get_candidates


def fetch_candidates(state):
    try:
        candidates = get_candidates()

        return {
            "candidates": candidates,
            "status": "CANDIDATES_LOADED",
        }

    except Exception as exc:
        return {
            "candidates": [],
            "errors": [f"Failed to fetch candidates: {str(exc)}"],
            "status": "FAILED",
        }